InAppBrowser
============

See [LICENSE.md][LICENSE.md] for license terms and conditions.

This `inAppBrowser` sample app illustrates the use of Apache Cordova
inAppBrowser API. With this sample app you can access webpages, open PDF files
and locally stored images.

Project Details
---------------

This app has been built and installed on Android Crosswalk, Android, iOS
and Windows 8 devices. It may run on other Cordova platforms, but has not been
tested on those other platforms.

To see the technical details of the sample, please read the
[included tutorial](docs/README.md).
